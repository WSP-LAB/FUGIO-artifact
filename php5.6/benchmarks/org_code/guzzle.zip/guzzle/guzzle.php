<?php
/*
  Plugin Name: Guzzle
  Description: Guzzle
  Version: 1.0.0
 */

include_once('vendor/autoload.php');
