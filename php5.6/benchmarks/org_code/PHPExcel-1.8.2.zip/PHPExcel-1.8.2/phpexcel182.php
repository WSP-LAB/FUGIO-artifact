<?php
/*
  Plugin Name: PHPExcel
  Description: PHPExcel
  Version: 1.0.0
 */

include_once('PHPExcel-1.8.2/Classes/PHPExcel.php');