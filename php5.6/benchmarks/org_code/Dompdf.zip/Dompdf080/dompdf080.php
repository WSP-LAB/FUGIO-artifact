<?php
/*
  Plugin Name: DomPDF
  Description: DomPDF
  Version: 1.0.0
 */

include_once('vendor/autoload.php');
