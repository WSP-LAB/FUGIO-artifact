<?php
return [
    'TYPO3\\CMS\\Backend\\AjaxLoginHandler' => \TYPO3\CMS\Backend\Controller\AjaxLoginController::class,
    'TYPO3\\CMS\\Backend\\Form\\Wizard\\ImageManipulationWizard' => \TYPO3\CMS\Backend\Controller\Wizard\ImageManipulationController::class,
];
