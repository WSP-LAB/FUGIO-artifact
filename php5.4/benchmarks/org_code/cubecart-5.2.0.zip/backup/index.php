<?php
die('Access denied');