<?php
if (!defined('CC_INI_SET')) die('Access Denied');
$page_content = $GLOBALS['smarty']->fetch('templates/upgrade.index.php');